# JobbPiloten Scraper

Isolated Playwright-based job field scraper for Swedish job sites.
Completely separate from the JobbPiloten app - nothing here touches
~/jobbpiloten-se.

## Quick start

```bash
npm install
npx playwright install chromium
npm run scrape -- lager          # scrape keyword 'lager' across all enabled sites
npm run scrape -- lager lernia,bemannia,randstad   # scrape specific sites
npm run process                  # JSONL -> CSV + schema.json
npm run test:sites               # smoke tests (chromium launch + HTML site selectors)
node scripts/probe-site.js <url>      # dev tool: find selectors on a new site
node scripts/sniff-academicwork.js      # AW XHR/RSC endpoint discovery notes
```

Output: `data/raw/scraped_fields.jsonl` (raw, gitignored) and
`data/processed/scraped_fields.csv` + `scraped_fields.schema.json`.

## Sites (16) - status verified live 2026-08-02

| # | Site | Type | Status | Notes |
|---|------|------|--------|-------|
| 1 | Arbetsförmedlingen | api | enabled | JobTech API, no key, q/limit/offset/sort |
| 2 | Lernia | html | enabled | SSR archive, /jobb/<cat>/<...>-<id>/ |
| 3 | Bemannia | html | enabled | ATS at career.bemannia.se, /jobs/<id>-<slug> (+ /jobs.rss) |
| 4 | Wise IT | html | enabled | wise.se (wiseit.se redirects), /jobb/<slug>-<id>/ |
| 5 | Randstad | html | enabled | UUID URLs in .cards__list; searchUrl ?q= |
| 6 | Jobbsafari | html | enabled | MUI cards; /jobb/<slug>-<id> |
| 7 | TNG | html | enabled | .jobitem cards; robots allows jobs |
| 8 | Academic Work | html | enabled | SSR pivot: ?ft=<keyword> server-filters the list (no JS/auth). Caps at 10 results/keyword; accent-required queries (vard/salj return 0) |
| 9 | Manpower | html | disabled | SPA search widget; server HTML has no job links |
| 10 | Adecco | html | disabled | adecco.com/sv-se SPA widget; no SSR job links |
| 11 | Poolia | html | disabled | WP job-listing widget; no SSR job links |
| 12 | Indeed (SE) | html | disabled | HTTP 403 Cloudflare bot-block |
| 13 | LinkedIn Jobs | html | disabled | Login wall + US region redirect; API needs OAuth |
| 14 | Blocket Jobb | html | disabled | HTTP 404 - jobs section discontinued |
| 15 | Metrojobb | html | disabled | Empty shell page - aggregator shut down |
| 16 | Framtiden | html | disabled | Jobs redirect to 2021 blog post; career subdomain dead |

### API vs HTML breakdown
- **api (1):** Arbetsförmedlingen via the public JobTech Job Search API
  (jobsearch.api.jobtechdev.se/search) - free, keyless, richest fields.
- **html (15):** headless Chromium + CSS selectors. Every list page is
  traversed either via `list.itemLinks` (selector + minPathSegments to
  exclude taxonomy pages) or via result cards
  (resultSelector x detailLinkSelector).

### Captured fields
- api sites: 17 mapped fields (headline, employer, location, region,
  employmentType, workingHours, duration, description, deadlines, ...).
- html sites: jobTitle (h1), description (meta), url, applicationUrl
  (auto-detected Ansök/Apply CTA). company/location selectors are still
  TODO per site - add to `fields` after inspecting a detail page with
  `node scripts/probe-site.js <detailUrl>`.

## Robots.txt notes
- randstad: allow /; disallow /en/jobs/*/km-  - /jobb/ OK
- manpower: disallow /candidate - jobs page would be OK if it were SSR
- adecco.com: disallow /data/, /infos/
- tng: disallow /wp-admin/, /search/
- wise.se: disallow wp-admin only
- career.bemannia.se: disallow /app/, /messages/ - /jobs/ OK
- jobbsafari: robots.txt served as redirect page (not enforced)

Default throttle: 1 request / 2 s (defaultRateLimitMs in sites.js).

## Skipped sites (low priority / blocked)
OnePartnerGroup, StudentConsulting, Jobby, The Hub - add later if needed.

## Taxonomy pipeline (Steps A-D)

The raw sweep produces tagged records (siteId, keyword, url, fields). The
taxonomy pipeline turns those into an application-form field schema for
the browser-extension auto-fill:

### Step A - Deduplicate & classify (scripts/classify-industries.js)
- Collapse raw records by webpageUrl -> unique jobs (503 before AW, 587 with
  the Academic Work sweep).
- Normalize titles (lowercase, strip punctuation).
- Batch-classify each unique job into 1 of 9 industry buckets
  (lager, vard, kontor, IT, bygg, restaurang, salj, industri, transport)
  via Groq llama-3.1-8b-instant (no reasoning overhead - qwen3.6 burns
  the 8K token/min window on mandatory reasoning, ~1 batch/5 min vs ~8
  batches/min for llama-8b). Keyword voting is the fallback when the LLM
  output is unparseable.
- Output: data/processed/job_industry_mapping.csv
  (jobUrl, predictedIndustry, confidence, keywordVotes, method).

### Step B - Extract form fields (scripts/extract-form-fields.js)
- Site-balanced sample of unique job URLs (per-site cap, skips the generic
  AF support page).
- Visits the detail page, dismisses cookie banners, finds the Ansok/Apply
  CTA (in-page anchor scroll, safe same-page click, or external URL).
- External ATS platforms (Teamtailor, ReachMee, ...) are tagged by URL;
  Teamtailor careersites expose the real form in-page behind the CTA.
- Extracts visible controls (input/select/textarea) with label, type,
  required, options, placeholder. Noise (search boxes, submit buttons,
  radio option labels, translate widgets) is filtered at taxonomy time.
- Output: data/processed/form_fields_raw.jsonl (append-safe).

### Step C - Tiered taxonomy (scripts/build-taxonomy.js)
- Canonical field ids (fornamn->name, e-post->email, ...) collapse label
  variants; frequencies are per-form (a field counts once per form).
- Tier 1 (Universal, >70% of forms): availability, name, last_name,
  email, phone, cv, cover_letter, other_documents (100% across the
  Bemannia Teamtailor forms).
- Tier 2 (Industry core, >40% within an industry, <=70%): screening
  questions and mid-frequency fields grouped by industry.
- Tier 3 (Job-specific, <10%): rare certifications/screening questions.
- Output: data/processed/universal_fields.csv,
  data/processed/industry_core_fields.csv.

### Step D - Extension schema (scripts/build-taxonomy.js)
- Output: data/processed/extension_field_schema.json with
  `universal`, `industry.<bucket>`, `jobSpecific`, `platforms.<ats>`
  field lists (canonical ids) - the contract the extension autofill
  renders against.

Re-run order after a sweep: classify-industries.js -> extract-form-fields.js
-> build-taxonomy.js.

## Full keyword sweep

```bash
npm run sweep                 # all enabled sites x 9 keywords, maxJobs 10
npm run sweep -- 50           # or pass a larger per-site maxJobs
bash scripts/sweep.sh 10      # explicit: sites x keywords x maxJobs
node scraper/runners/index.js lager lernia,bemannia 10   # one keyword, subset
```

Sweeps append to data/raw/scraped_fields.jsonl. Re-run npm run process
afterwards to regenerate the CSV + schema. HTML list pages are NOT
keyword-filterable (verified 2026-08-02) - each keyword re-reads the same
list and tags the records, so expect duplicated URLs across keywords
(useful for the keyword x URL taxonomy phase). The API site returns real
per-keyword results via offset pagination.

## Round-81 (2026-08-03) — 100+ form corpus push

The taxonomy was rebuilt on a substantially deeper corpus:

### Corpus growth
- Re-swept the form-rich HTML sites with raised caps (bemannia 30, wise 30,
  randstad 40, jobbsafari 40 + `?page=N` pagination, lernia 20, tng 20) —
  **689 unique jobs** classified into the 9 industries.
- `scripts/extract-form-fields.js` (Step B) was hardened:
  - **Resumable dedupe** — jobs that already yielded real fields are
    skipped; zero-field records are re-probed on re-runs.
  - **Iframe traversal** — same-origin child frames are scanned; the
    in-page noise filter was moved out of the frame function (a
    page-context ReferenceError was silently killing every frame
    extraction — the root cause of the previous ~14% form yield).
  - **Broader external navigation** — any non-dashboard apply URL is
    followed (unlocks ReachMee / Varbi / getwiser forms from
    aggregator detail pages), with modal-iframe `src` following for
    `#modal-iframe` embeds.
  - **Required flag** parsed from label text ("*Obligatoriskt").
  - **Login-wall detection** — pages exposing only email+password
    (Academic Work `/apply`) are recorded as `login-walled`, not
    empty forms.
- Form yield went from ~14% to ~45%: **102 application forms** from
  567 probes (64 complete with ≥5 real fields), across platforms
  Teamtailor / getwiser / Varbi / ReachMee / staffing-site / jobylon
  plus in-page forms.

### Taxonomy outputs (all three tiers have real data)
- `data/processed/universal_fields.csv` — Tier 1 (>70% of complete
  forms): förnamn, e-post, telefon (96.9% each).
- `data/processed/industry_core_fields.csv` — Tier 2 (>40% within
  industry, ≤70%): 25 rows across lager / vård / kontor / bygg /
  industri / sälj.
- `data/processed/job_specific_fields.csv` — Tier 3 (**210 rare labels**
  <10% of forms; the full table).
- `data/processed/extension_field_schema.json` — final schema with
  `universal`, `industry.<bucket>`, `jobSpecific` (top 60),
  `platforms.<ats>` field mappings.

### Known gaps (documented, not blocking)
- **Academic Work**: the SSR list caps at 10 results/keyword and IGNORES
  all pagination params (`?page=2`, `?offset=10`, `?start=10`,
  `?from=10`, `?sida=2` all return the same 10 links — re-verified
  2026-08-03). All 84 AW `/apply` pages are login-walled (only
  E-post + Lösenord inputs); no anonymous AW forms exist, so AW is a
  job-metadata source only.
- **Arbetsförmedlingen**: 444 jobs scraped, but Platsbanken exposes no
  anonymous application form (0 fields on job pages); excluded from the
  Step-B extraction pool.
- **Lernia / TNG**: career pages expose no real application form
  (only cookie/search widgets), so their records contribute job
  metadata but no forms.
- **Manpower / Adecco / Poolia / Indeed / LinkedIn / Blocket /
  Metrojobb / Framtiden**: remain disabled (SPA widgets, bot-gates,
  or shut-down sections — see the sites table above).

Re-run order after any sweep: `classify-industries.js` ->
`extract-form-fields.js` -> `build-taxonomy.js`.
