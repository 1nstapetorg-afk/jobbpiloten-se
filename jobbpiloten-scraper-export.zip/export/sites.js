/**
 * Site definitions for the field scraper.
 *
 * Two site types:
 *   - type 'api':  fetch JSON from a public API endpoint (recommended).
 *   - type 'html': drive headless Chromium. The list page is either
 *     traversed via list.itemLinks (selector + minPathSegments to
 *     exclude taxonomy pages) or via result cards
 *     (list.resultSelector x list.detailLinkSelector). Detail pages are
 *     read through site.fields (selector / attribute / meta) plus an
 *     auto-detected application URL (Ansök / Apply CTA).
 *
 * All entries verified live 2026-08-02. Sites whose server HTML does
 * not expose job links (SPA widgets) or that are bot-gated are shipped
 * with enabled:false and a note - flip on only after adding a working
 * selector or a private API.
 *
 * Rate limits: polite 1 request / 2 s globally (defaultRateLimitMs);
 * per-site robots.txt findings are noted per entry below.
 */

const INDUSTRY_KEYWORDS = ['lager', 'vård', 'kontor', 'IT', 'bygg', 'restaurang', 'sälj', 'industri', 'transport'];

const sites = [
  // ------------------------------------------------------------------
  // 1. Arbetsförmedlingen - JobTech Job Search API (public, free, no key)
  //    GET https://jobsearch.api.jobtechdev.se/search
  //    params: q (free text), qf (field filter), limit (max 100),
  //    offset (max 1000), sort (relevance | pubdate-desc | ...)
  //    response: total { value }, hits[] with headline, employer.name,
  //    workplace_address.{city,municipality,region},
  //    employment_type.label, description.text, webpage_url, ...
  // ------------------------------------------------------------------
  {
    id: 'arbetsformedlingen',
    name: 'Arbetsförmedlingen',
    type: 'api',
    enabled: true,
    baseUrl: 'https://jobsearch.api.jobtechdev.se',
    api: {
      endpoint: 'https://jobsearch.api.jobtechdev.se/search',
      keyword: '',   // overridden by: npm run scrape -- <keyword>
      limit: 5,
      offset: 0,
      sort: 'relevance',
      recordMap: {
        jobTitle: 'headline',
        company: 'employer.name',
        workplace: 'employer.workplace',
        location: 'workplace_address.city',
        municipality: 'workplace_address.municipality',
        region: 'workplace_address.region',
        employmentType: 'employment_type.label',
        workingHours: 'working_hours_type.label',
        duration: 'duration.label',
        salaryType: 'salary_type.label',
        occupation: 'occupation.label',
        occupationField: 'occupation_field.label',
        description: 'description.text',
        webpageUrl: 'webpage_url',
        publicationDate: 'publication_date',
        applicationDeadline: 'application_deadline',
        vacancies: 'number_of_vacancies'
      }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 2. Lernia - server-rendered job archive (Next.js). Verified live.
  //    List: /jobb/ ; detail: /jobb/<category>/<cities>-<role>-lernia-<id>/
  //    Category links share the /jobb/ prefix -> minPathSegments 3.
  //    robots.txt: Lernia has no explicit job disallow (site-wide allow).
  // ------------------------------------------------------------------
  {
    id: 'lernia',
    name: 'Lernia',
    type: 'html',
    enabled: true,
    baseUrl: 'https://www.lernia.se',
    maxJobs: 40,
    list: {
      url: 'https://www.lernia.se/jobb/',
      itemLinks: { selector: 'a[href*=jobb]', minPathSegments: 3 }
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 3. Bemannia - careers ATS (career.bemannia.se). Verified live.
  //    List: / ; detail: /jobs/<id>-<slug> (also exposes /jobs.rss).
  //    robots.txt: disallow /app/ and /messages/ only - /jobs/ is fine.
  // ------------------------------------------------------------------
  {
    id: 'bemannia',
    name: 'Bemannia',
    type: 'html',
    enabled: true,
    baseUrl: 'https://career.bemannia.se',
    // Round-81 (2026-08-03): bumped 5 -> 30. Bemannia runs Teamtailor,
    // whose career page hosts the FULLEST application forms in the corpus
    // (name/email/phone/CV + per-job screening questions). The list page
    // ignores ?page=N (verified 2026-08-03) so the ceiling is the ~9-10
    // live jobs on / — raised cap just guarantees we always grab them all.
    maxJobs: 60,
    list: {
      url: 'https://career.bemannia.se/',
      itemLinks: { selector: 'a[href*=jobs]', minPathSegments: 2 }
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 4. Wise (IT/Tech) - wise.se (wiseit.se redirects here). Verified.
  //    List: /specialistomraden/it/lediga-jobb/ ; cards .archive-item.job
  //    Detail: /jobb/<slug>-<id>/ . robots.txt: only wp-admin blocked.
  // ------------------------------------------------------------------
  {
    id: 'wise',
    name: 'Wise IT',
    type: 'html',
    enabled: true,
    baseUrl: 'https://www.wise.se',
    // Round-81: 5 -> 30. Wise apply links route to getwiser.se/jobs/external/
    // which hosts real (if minimal) application forms — a second ATS
    // platform in the corpus alongside Teamtailor.
    maxJobs: 60,
    list: {
      url: 'https://www.wise.se/specialistomraden/it/lediga-jobb/',
      itemLinks: { selector: '.archive-item.job a[href*=jobb]', minPathSegments: 2 }
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 5. Randstad - server-rendered, UUID job URLs. Verified live.
  //    List: /jobb/ ; job cards live in .cards__list and each card is a
  //    link /jobb/<slug>_<uuid>/ . Megamenu shares /jobb/ prefix, so the
  //    selector is scoped to .cards__list. robots.txt allows /jobb/.
  // ------------------------------------------------------------------
  {
    id: 'randstad',
    name: 'Randstad',
    type: 'html',
    enabled: true,
    baseUrl: 'https://www.randstad.se',
    // Round-81: 5 -> 40. The /jobb/ list page renders ~40 UUID job links
    // (verified 2026-08-03); ?page=N is ignored so this is the ceiling.
    // Randstad jobs apply through Randstad's own wizard — a separate
    // application flow to capture for platform variety.
    maxJobs: 40,
    list: {
      url: 'https://www.randstad.se/jobb/',
      itemLinks: { selector: 'a[href*=jobb]', minPathSegments: 2, urlPattern: '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' }
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 6. Jobbsafari - aggregator (Material UI). Verified live.
  //    List: /lediga-jobb ; cards .MuiCard-root (42 on the page)
  //    Detail: /jobb/<slug>-<id> . robots.txt served as a redirect page.
  // ------------------------------------------------------------------
  {
    id: 'jobbsafari',
    name: 'Jobbsafari',
    type: 'html',
    enabled: true,
    baseUrl: 'https://jobbsafari.se',
    // Round-81 (2026-08-03): 5 -> 40 + pagination. Jobbsafari is the key
    // cross-platform source: its detail pages' Ansök CTAs point at the
    // ORIGINAL employer ATS (Teamtailor/Varbi/ReachMee/…) so the form
    // extractor picks up many platforms from one aggregator. The list
    // supports ?page=N (verified live: page 2 exposes new cards) and the
    // URL is keyword-invariant (search params are ignored by the SSR
    // list), so pagination is how we reach more than the first page.
    maxJobs: 80,
    list: {
      url: 'https://jobbsafari.se/lediga-jobb',
      itemLinks: { selector: '.MuiCard-root a[href*=jobb]', minPathSegments: 2 },
      paginate: { param: 'page', startPage: 1 }
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 7. TNG - server-rendered job cards. Verified live.
  //    List: /lediga-jobb/ ; cards .jobitem (19 on the page, title inside
  //    .jobitem__title). Detail links are the first anchor in each card.
  //    robots.txt: disallow /wp-admin/ and /search/ only.
  // ------------------------------------------------------------------
  {
    id: 'tng',
    name: 'TNG',
    type: 'html',
    enabled: true,
    baseUrl: 'https://www.tng.se',
    maxJobs: 20,
    list: {
      url: 'https://www.tng.se/lediga-jobb/',
      resultSelector: '.jobitem',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 8. Academic Work - Next.js App Router + Payload CMS SPA.
  //
  // API discovery (2026-08-02, XHR interception in headless Chromium):
  //   - The SPA's job data rides in RSC flight payloads (?_rsc=<id>
  //     fetch requests); there is no public JSON API.
  //   - A Payload REST collection EXISTS at /api/jobs but is
  //     session-gated: anonymous GET -> 500, POST -> 403
  //     ("You are not allowed to perform this action"), and where-
  //     clauses are rejected 400. Fields are NOT queryable without an
  //     authenticated Payload session cookie.
  //   - Workaround (implemented): the job LIST page is fully
  //     server-rendered - plain GET /lediga-jobb?page=N returns 10
  //     fresh job links per page with NO JS and NO auth. Detail pages
  //     also SSR (h1, meta description, Arbetsgivare/Plats label rows,
  //     Ansok CTA). So we scrape HTML + paginate. No session needed.
  //   - Pagination: ?page=2..N confirmed returning unique links.
  // ------------------------------------------------------------------
  {
    id: 'academicwork',
    name: 'Academic Work',
    type: 'html',
    enabled: true,
    baseUrl: 'https://www.academicwork.se',
    maxJobs: 10,
    list: {
      // KEY FIND: the search form submits ?ft=<keyword> and the SSR
      // page filters server-side - plain GET with NO JS/auth returns
      // only keyword-relevant jobs (verified: ft=lager -> lager jobs).
      // The site caps the SSR list at 10 results and ignores all
      // pagination params (page/offset/start/from/sida all return the
      // same 10) - so each keyword yields up to 10 highly relevant
      // records, far better than the keyword-invariant lists of the
      // other HTML sites.
      url: 'https://academicwork.se/lediga-jobb',
      searchUrl: 'https://academicwork.se/lediga-jobb?ft={keyword}',
      // Job cards are grid overlays: EVERY job anchor is an empty-text
      // <a> (textLen 0). urlPattern is the strong filter; the
      // extractor skips the text-length gate when a pattern is set.
      itemLinks: { selector: 'a[href*=lediga-jobb]', minPathSegments: 4, urlPattern: '\/lediga-jobb\/j\/' }
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' },
      employer: { labelSibling: 'Arbetsgivare' },
      location: { labelSibling: 'Plats' }
    },
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 9. Manpower - SKIPPED: job list is a client-side search app; server
  //    HTML exposes only 3 static feature cards with no job links.
  //    Full search requires their private widget API.
  // ------------------------------------------------------------------
  {
    id: 'manpower',
    name: 'Manpower',
    type: 'html',
    enabled: false,
    baseUrl: 'https://www.manpower.se',
    maxJobs: 5,
    list: {
      url: 'https://www.manpower.se/lediga-jobb',
      resultSelector: '.card.manpower_light',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'SPA job search widget - no job links in server HTML; needs private API',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 10. Adecco - SKIPPED: jobs moved to adecco.com/sv-se/lediga-jobb, a
  //     client-side search widget (SÖK JOBB button, no server-rendered
  //     job links). robots.txt disallows /data/ and /infos/.
  // ------------------------------------------------------------------
  {
    id: 'adecco',
    name: 'Adecco',
    type: 'html',
    enabled: false,
    baseUrl: 'https://www.adecco.com/sv-se',
    maxJobs: 5,
    list: {
      url: 'https://www.adecco.com/sv-se/lediga-jobb',
      resultSelector: '[class*=job-title]',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'Client-side search widget - no server-rendered job links',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 11. Poolia - SKIPPED: WordPress page with a client-side job-listing
  //     widget (wp-block-custom-blocks-job-listing); server HTML has no
  //     job links. Apply is a widget button.
  // ------------------------------------------------------------------
  {
    id: 'poolia',
    name: 'Poolia',
    type: 'html',
    enabled: false,
    baseUrl: 'https://poolia.se',
    maxJobs: 5,
    list: {
      url: 'https://poolia.se/lediga-jobb/',
      resultSelector: '.wp-block-custom-blocks-job-listing',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'Client-side job-listing widget - no server-rendered job links',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 12. Indeed (SE) - SKIPPED: returns HTTP 403 Blocked - Cloudflare for
  //     headless browsers. No public API for job seekers.
  // ------------------------------------------------------------------
  {
    id: 'indeed',
    name: 'Indeed Sverige',
    type: 'html',
    enabled: false,
    baseUrl: 'https://se.indeed.com',
    maxJobs: 5,
    list: {
      url: 'https://se.indeed.com/jobs?q=lager',
      resultSelector: '.job_seen_beacon',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'HTTP 403 Cloudflare bot-block for headless clients',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 13. LinkedIn Jobs (SE) - SKIPPED: public search is login-walled and
  //     region-redirects to the US site; jobs API requires OAuth.
  // ------------------------------------------------------------------
  {
    id: 'linkedin',
    name: 'LinkedIn Jobs',
    type: 'html',
    enabled: false,
    baseUrl: 'https://www.linkedin.com',
    maxJobs: 5,
    list: {
      url: 'https://www.linkedin.com/jobs/search?keywords=lager',
      resultSelector: '.job-card-container',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'Login-walled search + US region redirect; jobs API needs OAuth',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 14. Blocket Jobb - SKIPPED: /jobb returns HTTP 404 - the jobs
  //     section has been discontinued on Blocket.
  // ------------------------------------------------------------------
  {
    id: 'blocket',
    name: 'Blocket Jobb',
    type: 'html',
    enabled: false,
    baseUrl: 'https://www.blocket.se',
    maxJobs: 5,
    list: {
      url: 'https://www.blocket.se/jobb',
      resultSelector: 'article',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'HTTP 404 - Blocket jobs section discontinued',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 15. Metrojobb - SKIPPED: the domain serves an empty shell page with
  //     no job content or links (aggregator effectively shut down).
  // ------------------------------------------------------------------
  {
    id: 'metrojobb',
    name: 'Metrojobb',
    type: 'html',
    enabled: false,
    baseUrl: 'https://www.metrojobb.se',
    maxJobs: 5,
    list: {
      url: 'https://www.metrojobb.se',
      resultSelector: 'article',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'Empty shell page - no job content or links',
    industryKeywords: INDUSTRY_KEYWORDS
  },

  // ------------------------------------------------------------------
  // 16. Framtiden - SKIPPED: framtiden.se is a real-estate blog whose
  //     /lediga-jobb redirects to a 2021 blog post; career.framtiden.se
  //     is unreachable (connection timeout). Staffing jobs are not
  //     exposed server-side.
  // ------------------------------------------------------------------
  {
    id: 'framtiden',
    name: 'Framtiden',
    type: 'html',
    enabled: false,
    baseUrl: 'https://framtiden.se',
    maxJobs: 5,
    list: {
      url: 'https://framtiden.se/lediga-jobb',
      resultSelector: 'article',
      detailLinkSelector: 'a[href]'
    },
    fields: {
      jobTitle: { selector: 'h1' },
      description: { meta: 'description' }
    },
    blockedReason: 'Jobs redirect to a 2021 blog post; career subdomain unreachable',
    industryKeywords: INDUSTRY_KEYWORDS
  }
];

module.exports = {
  sites,
  defaultRateLimitMs: 2000, // 1 request / 2 s, polite robots-friendly default
  rawOutputFile: 'data/raw/scraped_fields.jsonl'
};
